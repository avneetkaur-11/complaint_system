# Complaints AI Teammate Python Backend

## Run locally

1. Create and activate a Python virtual environment.
2. Install dependencies:
   `pip install -r requirements.txt`
3. Start PostgreSQL with the `pgvector` extension enabled.
4. Set the database URL:
   `set DATABASE_URL=postgresql+psycopg://postgres:postgres@localhost:5432/complaints`
5. Start the API:
   `uvicorn app.main:app --reload --port 8000`

The frontend already expects `/api/graphql`; in development you can proxy `/api` to `http://localhost:8000` by updating the Vite config.
