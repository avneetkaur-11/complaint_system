import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from fastapi.testclient import TestClient
from app.main import app
from app.routers.graphql_api import graphql
from app.schemas import GraphQLRequest


class DummyQuery:
    def filter(self, *args, **kwargs):
        return self

    def first(self):
        return None


class DummyDB:
    def query(self, *args, **kwargs):
        return DummyQuery()


def test_submit_complaint_accepts_frontend_mutation_name():
    client = TestClient(app)
    response = client.post(
        '/graphql',
        json={
            'query': 'mutation($input: ComplaintIntakeInput!) { submitComplaint(input: $input) { caseId status } }',
            'variables': {
                'input': {
                    'clientId': 'demo-client',
                    'channel': 'web',
                    'description': 'Billing issue',
                    'clientName': 'Ada',
                    'clientEmail': 'ada@example.com',
                    'clientPhone': '555-0100',
                }
            },
        },
    )
    assert response.status_code == 200, response.text


def test_case_lookup_returns_null_for_malformed_id():
    request = GraphQLRequest(
        query='query($caseId: ID!) { caseById(caseId: $caseId) { caseId } }',
        variables={'caseId': 'not-a-uuid'},
    )

    response = graphql(request, db=DummyDB())

    assert response == {'data': {'caseById': None}}
