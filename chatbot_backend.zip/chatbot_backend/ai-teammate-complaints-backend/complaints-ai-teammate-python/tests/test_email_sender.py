from app.services.email_service import EmailService


def test_email_service_formats_status_message():
    service = EmailService.from_settings(
        smtp_host='smtp.example.test',
        smtp_port=2525,
        smtp_username='user',
        smtp_password='pass',
        from_address='no-reply@example.com',
        enabled=True,
    )

    message = service.build_message(
        to_address='customer@example.com',
        subject='Complaint update',
        body='Body',
    )

    assert message['To'] == 'customer@example.com'
    assert message['From'] == 'no-reply@example.com'
    assert message['Subject'] == 'Complaint update'


def test_email_service_falls_back_when_smtp_is_not_configured():
    service = EmailService.from_settings(
        smtp_host='localhost',
        smtp_port=25,
        smtp_username=None,
        smtp_password=None,
        from_address='no-reply@example.com',
        enabled=True,
    )

    assert service.send(
        to_address='customer@example.com',
        subject='Complaint update',
        body='Body',
    ) is False
