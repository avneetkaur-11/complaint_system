from app.services.classification_service import ClassificationService


def test_mock_ai_classification_is_deterministic():
    service = ClassificationService()
    result = service.classify("I was charged twice for the same subscription")

    assert result.category == "billing"
    assert result.subCategory == "refund_request"
    assert result.severity == "medium"


def test_mock_ai_recommendation_is_generated():
    service = ClassificationService()
    result = service.classify("My card was used without my permission")
    action, confidence = service.generate_recommendation(result)

    assert "verify" in action.lower() or "freeze" in action.lower()
    assert confidence >= 0.8
