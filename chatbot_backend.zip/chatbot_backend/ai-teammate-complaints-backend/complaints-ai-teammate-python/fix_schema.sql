ALTER TABLE agent_findings ALTER COLUMN retrieved_context_ids TYPE JSONB USING COALESCE(retrieved_context_ids::TEXT, '[]')::JSONB;
