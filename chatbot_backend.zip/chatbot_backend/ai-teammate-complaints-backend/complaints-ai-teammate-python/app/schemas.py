from datetime import datetime
from typing import Optional
from uuid import UUID
from pydantic import BaseModel, Field


class ComplaintIntakeRequest(BaseModel):
    clientId: str
    channel: str
    description: str
    clientName: Optional[str] = None
    clientEmail: Optional[str] = None
    clientPhone: Optional[str] = None


class ComplaintUpdateRequest(BaseModel):
    description: Optional[str] = None
    clientName: Optional[str] = None
    clientEmail: Optional[str] = None
    clientPhone: Optional[str] = None


class CaseResponse(BaseModel):
    caseId: UUID
    clientId: str
    channel: str
    rawDescription: str
    category: Optional[str]
    subCategory: Optional[str]
    severity: Optional[str]
    summary: Optional[str]
    status: str
    recommendedAction: Optional[str]
    recommendationConfidence: Optional[float]
    createdAt: Optional[datetime]
    updatedAt: Optional[datetime]
    clientName: Optional[str]
    clientEmail: Optional[str]
    clientPhone: Optional[str]


class AgentFindingResponse(BaseModel):
    findingId: UUID
    agentName: str
    findingType: str
    content: str
    confidence: Optional[float]
    retrievedContextIds: Optional[list[str]]
    createdAt: Optional[datetime]


class ApprovalDecisionRequest(BaseModel):
    decidedBy: str


class ApprovalQueueItem(BaseModel):
    approvalId: UUID
    status: str
    case: CaseResponse


class KnowledgeBaseCreateRequest(BaseModel):
    title: str
    content: str
    docType: Optional[str] = None


class KnowledgeBaseResponse(BaseModel):
    docId: UUID
    title: str
    docType: str
    chunksIndexed: int


class GraphQLRequest(BaseModel):
    query: str
    variables: Optional[dict] = None
