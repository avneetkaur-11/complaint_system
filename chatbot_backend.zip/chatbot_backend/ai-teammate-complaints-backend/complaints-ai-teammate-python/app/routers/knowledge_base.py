from fastapi import APIRouter, Depends, status
from sqlalchemy.orm import Session
from app.db import SessionLocal
from app.schemas import KnowledgeBaseCreateRequest, KnowledgeBaseResponse
from app.models.knowledge_base_model import KnowledgeBaseModel
from app.services.retrieval_service import RetrievalService

router = APIRouter()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@router.post("", response_model=KnowledgeBaseResponse, status_code=status.HTTP_201_CREATED)
def ingest(request: KnowledgeBaseCreateRequest, db: Session = Depends(get_db)):
    doc = KnowledgeBaseModel(title=request.title, content=request.content, doc_type=request.docType or "policy")
    db.add(doc)
    db.flush()

    service = RetrievalService(db)
    chunks = [chunk for chunk in request.content.split("\n") if chunk.strip()]
    for chunk in chunks:
        service.index_knowledge_base_doc(doc.doc_id, chunk, doc.title, doc.doc_type)

    db.commit()
    return KnowledgeBaseResponse(docId=doc.doc_id, title=doc.title, docType=doc.doc_type, chunksIndexed=len(chunks))
