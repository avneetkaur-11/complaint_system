from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db import SessionLocal
from app.schemas import ApprovalDecisionRequest, ApprovalQueueItem, CaseResponse, AgentFindingResponse
from app.models.approval_item_model import ApprovalItemModel
from app.models.case_model import CaseModel
from app.models.agent_finding_model import AgentFindingModel
from app.services.case_service import CaseService
from uuid import UUID

router = APIRouter()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def to_case_response(case: CaseModel) -> CaseResponse:
    return CaseResponse(
        caseId=case.case_id,
        clientId=case.client_id,
        channel=case.channel,
        rawDescription=case.raw_description,
        category=case.category,
        subCategory=case.sub_category,
        severity=case.severity,
        summary=case.summary,
        status=case.status,
        recommendedAction=case.recommended_action,
        recommendationConfidence=case.recommendation_confidence,
        createdAt=case.created_at,
        updatedAt=case.updated_at,
        clientName=case.client_name,
        clientEmail=case.client_email,
        clientPhone=case.client_phone,
    )


@router.get("", response_model=list[ApprovalQueueItem])
def list_pending(db: Session = Depends(get_db)):
    items = db.query(ApprovalItemModel).filter(ApprovalItemModel.status == "PENDING").order_by(ApprovalItemModel.created_at.asc()).all()
    return [
        ApprovalQueueItem(
            approvalId=item.approval_id,
            status=item.status,
            case=to_case_response(db.query(CaseModel).filter(CaseModel.case_id == item.case_id).first()),
        )
        for item in items
    ]


@router.post("/{approval_id}/approve", response_model=ApprovalQueueItem)
def approve(approval_id: UUID, decision: ApprovalDecisionRequest, db: Session = Depends(get_db)):
    service = CaseService(db)
    try:
        item = service.approve(approval_id, decision.decidedBy)
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    case = db.query(CaseModel).filter(CaseModel.case_id == item.case_id).first()
    return ApprovalQueueItem(approvalId=item.approval_id, status=item.status, case=to_case_response(case))


@router.post("/{approval_id}/reject", response_model=ApprovalQueueItem)
def reject(approval_id: UUID, decision: ApprovalDecisionRequest, db: Session = Depends(get_db)):
    service = CaseService(db)
    try:
        item = service.reject(approval_id, decision.decidedBy)
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    case = db.query(CaseModel).filter(CaseModel.case_id == item.case_id).first()
    return ApprovalQueueItem(approvalId=item.approval_id, status=item.status, case=to_case_response(case))
