from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.db import SessionLocal
from app.models.approval_item_model import ApprovalItemModel
from app.models.case_model import CaseModel
from app.models.knowledge_base_model import KnowledgeBaseModel, KnowledgeChunkModel
from app.schemas import ComplaintIntakeRequest, ComplaintUpdateRequest, GraphQLRequest
from app.services.case_service import CaseService
from app.services.retrieval_service import RetrievalService

router = APIRouter()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def _coerce_uuid(value):
    if value is None:
        return None
    if isinstance(value, UUID):
        return value
    try:
        return UUID(str(value))
    except (AttributeError, TypeError, ValueError):
        return None


def _serialize_case(case: CaseModel) -> dict:
    return {
        "caseId": str(case.case_id),
        "clientId": case.client_id,
        "channel": case.channel,
        "rawDescription": case.raw_description,
        "category": case.category,
        "subCategory": case.sub_category,
        "severity": case.severity,
        "summary": case.summary,
        "status": case.status,
        "recommendedAction": case.recommended_action,
        "recommendationConfidence": case.recommendation_confidence,
        "createdAt": case.created_at.isoformat() if case.created_at else None,
        "updatedAt": case.updated_at.isoformat() if case.updated_at else None,
        "clientName": case.client_name,
        "clientEmail": case.client_email,
        "clientPhone": case.client_phone,
        "findings": [],
    }


@router.post("")
def graphql(request: GraphQLRequest, db: Session = Depends(get_db)):
    query = request.query or ""
    variables = request.variables or {}

    if "submitComplaint" in query or "createComplaint" in query:
        input_data = variables.get("input", {})
        service = CaseService(db)
        case = service.intake(ComplaintIntakeRequest(**input_data))
        service.create_approval_item(case)
        result = _serialize_case(case)
        return {"data": {"submitComplaint": result, "createComplaint": result}}

    if "updateComplaint" in query:
        input_data = variables.get("input", {})
        case_id = _coerce_uuid(variables.get("caseId"))
        if case_id is None:
            return {"data": {"updateComplaint": None}, "errors": [{"message": "Invalid case ID"}]}
        service = CaseService(db)
        case = service.update_complaint(case_id, ComplaintUpdateRequest(**input_data))
        return {"data": {"updateComplaint": _serialize_case(case)}}

    if "ingestKnowledgeBaseDoc" in query:
        input_data = variables.get("input", {})
        doc = KnowledgeBaseModel(title=input_data["title"], content=input_data["content"], doc_type=input_data.get("docType") or "policy")
        db.add(doc)
        db.flush()
        retrieval = RetrievalService(db)
        chunks = [chunk for chunk in doc.content.split("\n") if chunk.strip()]
        for chunk in chunks:
            retrieval.index_knowledge_base_doc(doc.doc_id, chunk, doc.title, doc.doc_type)
        db.commit()
        return {"data": {"ingestKnowledgeBaseDoc": {"docId": str(doc.doc_id), "title": doc.title, "docType": doc.doc_type, "chunksIndexed": len(chunks)}}}

    if "approve" in query:
        approval_id = _coerce_uuid(variables.get("approvalId") or variables.get("input", {}).get("approvalId"))
        decided_by = variables.get("decidedBy") or variables.get("decider")
        if approval_id is None:
            return {"data": {"approve": None}, "errors": [{"message": "Invalid approval ID"}]}
        service = CaseService(db)
        item = service.approve(approval_id, decided_by)
        case = db.query(CaseModel).filter(CaseModel.case_id == item.case_id).first()
        return {"data": {"approve": {"approvalId": str(item.approval_id), "status": item.status, "case": _serialize_case(case)}}}

    if "reject" in query:
        approval_id = _coerce_uuid(variables.get("approvalId") or variables.get("input", {}).get("approvalId"))
        decided_by = variables.get("decidedBy") or variables.get("decider")
        if approval_id is None:
            return {"data": {"reject": None}, "errors": [{"message": "Invalid approval ID"}]}
        service = CaseService(db)
        item = service.reject(approval_id, decided_by)
        case = db.query(CaseModel).filter(CaseModel.case_id == item.case_id).first()
        return {"data": {"reject": {"approvalId": str(item.approval_id), "status": item.status, "case": _serialize_case(case)}}}

    if "caseById" in query:
        case_id = _coerce_uuid(variables.get("caseId"))
        if case_id is None:
            return {"data": {"caseById": None}}
        case = db.query(CaseModel).filter(CaseModel.case_id == case_id).first()
        return {"data": {"caseById": _serialize_case(case)}}

    if "approvalQueue" in query:
        items = db.query(ApprovalItemModel).filter(ApprovalItemModel.status == "PENDING").order_by(ApprovalItemModel.created_at.asc()).all()
        payload = []
        for item in items:
            case = db.query(CaseModel).filter(CaseModel.case_id == item.case_id).first()
            payload.append({"approvalId": str(item.approval_id), "status": item.status, "case": _serialize_case(case)})
        return {"data": {"approvalQueue": payload}}

    raise HTTPException(status_code=400, detail="Unsupported GraphQL operation")
