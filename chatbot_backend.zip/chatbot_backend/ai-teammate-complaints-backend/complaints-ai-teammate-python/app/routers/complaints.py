from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.orm import Session
from app.db import SessionLocal
from app.schemas import ComplaintIntakeRequest, ComplaintUpdateRequest, CaseResponse
from app.services.case_service import CaseService
from app.models.case_model import CaseModel
from app.models.agent_finding_model import AgentFindingModel
from app.models.approval_item_model import ApprovalItemModel
from uuid import UUID

router = APIRouter()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def to_case_response(case: CaseModel) -> CaseResponse:
    return CaseResponse(
        caseId=case.case_id,
        clientId=case.client_id,
        channel=case.channel,
        rawDescription=case.raw_description,
        category=case.category,
        subCategory=case.sub_category,
        severity=case.severity,
        summary=case.summary,
        status=case.status,
        recommendedAction=case.recommended_action,
        recommendationConfidence=case.recommendation_confidence,
        createdAt=case.created_at,
        updatedAt=case.updated_at,
        clientName=case.client_name,
        clientEmail=case.client_email,
        clientPhone=case.client_phone,
    )


@router.post("", response_model=CaseResponse, status_code=status.HTTP_201_CREATED)
def submit_complaint(request: ComplaintIntakeRequest, db: Session = Depends(get_db)):
    service = CaseService(db)
    case = service.intake(request)
    service.create_approval_item(case)
    return to_case_response(case)


@router.get("/{case_id}", response_model=CaseResponse)
def get_case(case_id: UUID, db: Session = Depends(get_db)):
    case = db.query(CaseModel).filter(CaseModel.case_id == case_id).first()
    if not case:
        raise HTTPException(status_code=404, detail="Case not found")
    return to_case_response(case)


@router.patch("/{case_id}", response_model=CaseResponse)
def update_complaint(case_id: UUID, request: ComplaintUpdateRequest, db: Session = Depends(get_db)):
    service = CaseService(db)
    try:
        case = service.update_complaint(case_id, request)
    except LookupError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return to_case_response(case)
