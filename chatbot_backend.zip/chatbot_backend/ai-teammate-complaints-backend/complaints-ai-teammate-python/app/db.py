from sqlalchemy import create_engine, text
from sqlalchemy.orm import declarative_base, sessionmaker
from app.config import get_settings

engine = create_engine(get_settings().database_url, echo=False)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def init_db() -> None:
    from app.models import case_model, agent_finding_model, approval_item_model, knowledge_base_model

    Base.metadata.create_all(bind=engine)

    with engine.begin() as conn:
        conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
        conn.execute(text("ALTER TABLE IF EXISTS cases ALTER COLUMN client_id TYPE VARCHAR USING client_id::TEXT"))
        conn.execute(text("ALTER TABLE IF EXISTS agent_findings ALTER COLUMN retrieved_context_ids TYPE JSONB USING COALESCE(retrieved_context_ids::TEXT, '[]')::JSONB"))
