import uuid
from sqlalchemy import Column, String, Float, DateTime, Text
from sqlalchemy.dialects.postgresql import UUID
from app.db import Base


class CaseModel(Base):
    __tablename__ = "cases"

    case_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    client_id = Column(String, nullable=False)
    channel = Column(String, nullable=False)
    raw_description = Column(Text, nullable=False)
    category = Column(String)
    sub_category = Column(String)
    severity = Column(String)
    summary = Column(Text)
    status = Column(String, default="NEW")
    recommended_action = Column(Text)
    recommendation_confidence = Column(Float)
    created_at = Column(DateTime(timezone=True), server_default="NOW()")
    updated_at = Column(DateTime(timezone=True), server_default="NOW()")
    client_name = Column(String)
    client_email = Column(String)
    client_phone = Column(String)
