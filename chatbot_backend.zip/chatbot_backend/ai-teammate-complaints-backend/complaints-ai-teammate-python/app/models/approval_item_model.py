import uuid
from sqlalchemy import Column, String, DateTime
from sqlalchemy.dialects.postgresql import UUID
from app.db import Base


class ApprovalItemModel(Base):
    __tablename__ = "approval_items"

    approval_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    case_id = Column(UUID(as_uuid=True), nullable=False)
    status = Column(String, default="PENDING")
    created_at = Column(DateTime(timezone=True), server_default="NOW()")
    decided_by = Column(String)
    decided_at = Column(DateTime(timezone=True))
