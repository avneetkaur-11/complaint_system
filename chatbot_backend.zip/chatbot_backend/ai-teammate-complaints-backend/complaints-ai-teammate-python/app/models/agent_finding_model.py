import uuid
from sqlalchemy import Column, String, Float, DateTime, Text
from sqlalchemy.dialects.postgresql import UUID, JSONB
from app.db import Base


class AgentFindingModel(Base):
    __tablename__ = "agent_findings"

    finding_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    case_id = Column(UUID(as_uuid=True), nullable=False)
    agent_name = Column(String, nullable=False)
    finding_type = Column(String, nullable=False)
    content = Column(Text, nullable=False)
    confidence = Column(Float)
    retrieved_context_ids = Column(JSONB, default=list)
    created_at = Column(DateTime(timezone=True), server_default="NOW()")
