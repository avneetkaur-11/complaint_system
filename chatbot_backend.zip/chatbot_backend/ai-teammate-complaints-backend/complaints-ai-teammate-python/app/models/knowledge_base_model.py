import uuid
from sqlalchemy import Column, String, DateTime, Text
from sqlalchemy.dialects.postgresql import UUID
from pgvector.sqlalchemy import Vector
from app.db import Base


class KnowledgeBaseModel(Base):
    __tablename__ = "knowledge_base"

    doc_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    title = Column(String, nullable=False)
    content = Column(Text, nullable=False)
    doc_type = Column(String, default="policy")
    # created_at = Column(DateTime(timezone=True), server_default="NOW()")


class KnowledgeChunkModel(Base):
    __tablename__ = "knowledge_chunks"

    chunk_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    doc_id = Column(UUID(as_uuid=True), nullable=False)
    chunk_text = Column(Text, nullable=False)
    title = Column(String)
    doc_type = Column(String)
    embedding = Column(Vector(1536))
    created_at = Column(DateTime(timezone=True), server_default="NOW()")
