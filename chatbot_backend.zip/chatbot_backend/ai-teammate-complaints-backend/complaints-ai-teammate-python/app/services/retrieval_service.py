from typing import List
from uuid import UUID

from sqlalchemy.orm import Session

from app.models.knowledge_base_model import KnowledgeChunkModel
from app.config import get_settings


class RetrievalService:
    def __init__(self, db: Session):
        self.db = db

    def index_knowledge_base_doc(self, doc_id: UUID, chunk_text: str, title: str, doc_type: str) -> None:
        self.db.add(KnowledgeChunkModel(doc_id=doc_id, chunk_text=chunk_text, title=title, doc_type=doc_type))
        self.db.commit()

    def index_resolution_note(self, case_id: UUID, recommended_action: str, category: str | None) -> None:
        self.db.add(
            KnowledgeChunkModel(
                doc_id=case_id,
                chunk_text=recommended_action or "Resolution note",
                title=(category or "resolution") + "-resolution",
                doc_type="resolution",
            )
        )
        self.db.commit()

    def get_relevant_chunks(self, query: str, limit: int = 5) -> List[KnowledgeChunkModel]:
        return self.db.query(KnowledgeChunkModel).filter(KnowledgeChunkModel.chunk_text.ilike(f"%{query}%")).limit(limit).all()
