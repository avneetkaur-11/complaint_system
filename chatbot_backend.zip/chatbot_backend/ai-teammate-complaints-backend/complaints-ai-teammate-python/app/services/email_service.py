import os
import smtplib
from email.message import EmailMessage
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv


load_dotenv(Path(__file__).resolve().parents[2] / ".env")


class EmailService:
    def __init__(self, *, enabled: bool, smtp_host: str, smtp_port: int, smtp_username: Optional[str], smtp_password: Optional[str], from_address: str):
        self.enabled = enabled
        self.smtp_host = smtp_host
        self.smtp_port = smtp_port
        self.smtp_username = smtp_username
        self.smtp_password = smtp_password
        self.from_address = from_address

    @classmethod
    def from_settings(cls, *, enabled: Optional[bool] = None, smtp_host: Optional[str] = None, smtp_port: Optional[int] = None, smtp_username: Optional[str] = None, smtp_password: Optional[str] = None, from_address: Optional[str] = None) -> "EmailService":
        return cls(
            enabled=enabled if enabled is not None else os.getenv("SMTP_ENABLED", "false").lower() == "true",
            smtp_host=smtp_host or os.getenv("SMTP_HOST", "localhost"),
            smtp_port=int(smtp_port or int(os.getenv("SMTP_PORT", "587"))),
            smtp_username=smtp_username if smtp_username is not None else os.getenv("SMTP_USERNAME"),
            smtp_password=smtp_password if smtp_password is not None else os.getenv("SMTP_PASSWORD"),
            from_address=from_address or os.getenv("SMTP_FROM", "aiteammateops@gmail.com"),
        )

    def build_message(self, *, to_address: str, subject: str, body: str) -> EmailMessage:
        message = EmailMessage()
        message["From"] = self.from_address
        message["To"] = to_address
        message["Subject"] = subject
        message.set_content(body)
        return message

    def send(self, *, to_address: str, subject: str, body: str) -> bool:
        if not self.enabled:
            print(f"[email disabled] would send to {to_address}: {subject}")
            return False

        if not self.smtp_host or self.smtp_host == "localhost" and not self.smtp_username:
            print(f"[email disabled] would send to {to_address}: {subject}")
            return False

        message = self.build_message(to_address=to_address, subject=subject, body=body)
        try:
            with smtplib.SMTP(self.smtp_host, self.smtp_port) as server:
                if self.smtp_username:
                    server.starttls()
                    server.login(self.smtp_username, self.smtp_password or "")
                server.send_message(message)
            return True
        except Exception as exc:
            print(f"[email send failed] {exc}")
            return False
def send_complaint_logged_email(email_service: EmailService, case) -> bool:
    if not case.client_email:
        return False

    subject = f"We've received your complaint ({case.case_id})"

    body = f"""Hi {case.client_name or "Customer"},

We've successfully received your complaint.

Case ID: {case.case_id}

You can use this Case ID to track your complaint.

Regards,
Complaint Ops Team
"""

    return email_service.send(
        to_address=case.client_email,
        subject=subject,
        body=body,
    )


def send_case_status_email(email_service: EmailService, case, status: str) -> bool:
    if not case.client_email:
        return False

    subject = f"Complaint Update ({case.case_id})"

    body = f"""Hi {case.client_name or "Customer"},

Your complaint status has been updated.

Case ID: {case.case_id}
Status: {status}

Regards,
Complaint Ops Team
"""

    return email_service.send(
        to_address=case.client_email,
        subject=subject,
        body=body,
    )