import re
from typing import NamedTuple


class ClassificationResult(NamedTuple):
    category: str
    subCategory: str
    severity: str
    summary: str


class ClassificationService:
    def classify(self, description: str) -> ClassificationResult:
        text = (description or "").strip().lower()
        if "refund" in text or "charge" in text:
            category = "billing"
            sub_category = "refund_request"
            severity = "medium"
        elif "fraud" in text or "unauthorized" in text or "stolen" in text or "card" in text:
            category = "security"
            sub_category = "unauthorized_transaction"
            severity = "high"
        elif "late" in text or "delay" in text or "service" in text:
            category = "service"
            sub_category = "service_delay"
            severity = "medium"
        else:
            category = "general"
            sub_category = "other"
            severity = "low"

        summary = re.sub(r"\s+", " ", description).strip() or "Customer complaint received"
        return ClassificationResult(category=category, subCategory=sub_category, severity=severity, summary=summary)

    def generate_recommendation(self, classification: ClassificationResult) -> tuple[str, float]:
        if classification.category == "security":
            return "Freeze the affected card and verify the transaction with the customer before proceeding.", 0.95
        if classification.category == "billing":
            return "Refund the disputed amount after verifying the transaction history.", 0.9
        if classification.category == "service":
            return "Escalate the service issue and provide a courtesy credit if policy allows.", 0.84
        return "Acknowledge the complaint and route it to the appropriate support team.", 0.8
