from datetime import datetime, timezone
from typing import Optional
from uuid import UUID

from sqlalchemy.orm import Session

from app.models.case_model import CaseModel
from app.models.agent_finding_model import AgentFindingModel
from app.models.approval_item_model import ApprovalItemModel
from app.schemas import ComplaintIntakeRequest, ComplaintUpdateRequest
from app.services.classification_service import ClassificationService
from app.services.email_service import EmailService, send_case_status_email, send_complaint_logged_email


class CaseService:
    def __init__(self, db: Session):
        self.db = db
        self.classifier = ClassificationService()
        self.email_service = EmailService.from_settings()

    def _notify_case_status_change(self, case: CaseModel, status: str) -> None:
        send_case_status_email(self.email_service, case, status)

    def intake(self, request: ComplaintIntakeRequest) -> CaseModel:
        classification = self.classifier.classify(request.description)
        recommended_action, confidence = self.classifier.generate_recommendation(classification)
        case = CaseModel(
            client_id=request.clientId,
            channel=request.channel,
            raw_description=request.description,
            category=classification.category,
            sub_category=classification.subCategory,
            severity=classification.severity,
            summary=classification.summary,
            recommended_action=recommended_action,
            recommendation_confidence=confidence,
            status="NEW",
            updated_at=datetime.now(timezone.utc),
            client_name=request.clientName,
            client_email=request.clientEmail,
            client_phone=request.clientPhone,
        )
        self.db.add(case)
        self.db.flush()

        self.db.add(
            AgentFindingModel(
                case_id=case.case_id,
                agent_name="ClassifierAgent",
                finding_type="classification",
                content=(
                    f"category={classification.category}, "
                    f"subCategory={classification.subCategory}, "
                    f"severity={classification.severity}, "
                    f"summary={classification.summary}"
                ),
            )
        )
        self.db.commit()
        self.db.refresh(case)

        send_complaint_logged_email(self.email_service, case)

        return case

    def update_complaint(self, case_id: UUID, request: ComplaintUpdateRequest) -> CaseModel:
        case = self.db.query(CaseModel).filter(CaseModel.case_id == case_id).first()
        if not case:
            raise LookupError("Case not found")

        if request.clientName is not None:
            case.client_name = request.clientName
        if request.clientEmail is not None:
            case.client_email = request.clientEmail
        if request.clientPhone is not None:
            case.client_phone = request.clientPhone

        if request.description is not None and request.description.strip() and request.description != case.raw_description:
            case.raw_description = request.description
            classification = self.classifier.classify(request.description)
            recommended_action, confidence = self.classifier.generate_recommendation(classification)
            case.category = classification.category
            case.sub_category = classification.subCategory
            case.severity = classification.severity
            case.summary = classification.summary
            case.recommended_action = recommended_action
            case.recommendation_confidence = confidence
            self.db.add(
                AgentFindingModel(
                    case_id=case.case_id,
                    agent_name="ClassifierAgent",
                    finding_type="classification_update",
                    content=(
                        f"Customer corrected complaint details. Re-classified: "
                        f"category={classification.category}, "
                        f"subCategory={classification.subCategory}, "
                        f"severity={classification.severity}, "
                        f"summary={classification.summary}"
                    ),
                )
            )

        case.updated_at = datetime.now(timezone.utc)
        self.db.commit()
        self.db.refresh(case)
        return case

    def create_approval_item(self, case: CaseModel) -> ApprovalItemModel:
        item = ApprovalItemModel(case_id=case.case_id, status="PENDING")
        self.db.add(item)
        self.db.commit()
        self.db.refresh(item)
        return item

    def _resolve_approval_item(self, identifier: UUID) -> ApprovalItemModel:
        item = self.db.query(ApprovalItemModel).filter(ApprovalItemModel.approval_id == identifier).first()
        if item:
            return item

        case = self.db.query(CaseModel).filter(CaseModel.case_id == identifier).first()
        if case:
            item = self.db.query(ApprovalItemModel).filter(ApprovalItemModel.case_id == case.case_id).order_by(ApprovalItemModel.created_at.asc()).first()
            if item:
                return item

        raise LookupError("Approval item not found")

    def approve(self, approval_id: UUID, decided_by: str) -> ApprovalItemModel:
        item = self._resolve_approval_item(approval_id)
        item.status = "APPROVED"
        item.decided_by = decided_by
        item.decided_at = datetime.now(timezone.utc)
        case = self.db.query(CaseModel).filter(CaseModel.case_id == item.case_id).first()
        if case:
            case.status = "APPROVED"
            case.updated_at = datetime.now(timezone.utc)
            self._notify_case_status_change(case, "APPROVED")
        self.db.commit()
        self.db.refresh(item)
        return item

    def reject(self, approval_id: UUID, decided_by: str) -> ApprovalItemModel:
        item = self._resolve_approval_item(approval_id)
        item.status = "REJECTED"
        item.decided_by = decided_by
        item.decided_at = datetime.now(timezone.utc)
        case = self.db.query(CaseModel).filter(CaseModel.case_id == item.case_id).first()
        if case:
            case.status = "REJECTED"
            case.updated_at = datetime.now(timezone.utc)
            self._notify_case_status_change(case, "REJECTED")
        self.db.commit()
        self.db.refresh(item)
        return item