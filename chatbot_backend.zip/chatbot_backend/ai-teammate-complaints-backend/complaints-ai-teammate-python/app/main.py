from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.db import init_db
from app.routers import complaints, knowledge_base, approval_queue, graphql_api

app = FastAPI(title="Complaints AI Teammate", version="2.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(complaints.router, prefix="/complaints", tags=["complaints"])
app.include_router(knowledge_base.router, prefix="/knowledge-base", tags=["knowledge-base"])
app.include_router(approval_queue.router, prefix="/approval-queue", tags=["approval-queue"])
app.include_router(graphql_api.router, prefix="/graphql", tags=["graphql"])

@app.on_event("startup")
def startup_event() -> None:
    init_db()
